export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  color?: string;
  size?: string;
  image: string;
}

export interface OrderItem {
  product_id: string;
  quantity: number;
}

export interface Order {
  id: string;
  items: {
    product: Product;
    quantity: number;
  }[];
  total: number;
  date: string;
}

export interface ToolCallParams {
  filters?: Record<string, any>;
  line_items?: OrderItem[];
}

// Log entry for the UI to show what happened
export interface ActivityLog {
  id: string;
  type: 'user' | 'agent' | 'tool';
  text?: string;
  data?: any; // Products or Order details
  timestamp: Date;
}