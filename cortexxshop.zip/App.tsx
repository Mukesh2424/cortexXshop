import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { createBlob, decode, decodeAudioData } from './utils/audioUtils';
import { list_products, create_order, get_last_order } from './utils/mockMerchant';
import { SYSTEM_INSTRUCTION, listProductsTool, createOrderTool, getLastOrderTool } from './utils/constants';
import { Product, Order, ActivityLog } from './types';
import { Visualizer } from './components/Visualizer';
import { ProductList, OrderCard } from './components/ProductList';

interface ChatMessage {
  id: string;
  role: 'user' | 'agent';
  text: string;
}

const App: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false); // Model is speaking
  const [products, setProducts] = useState<Product[]>([]);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  
  // Chat State
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [streamingMessage, setStreamingMessage] = useState<ChatMessage | null>(null);

  // Refs for audio and state handling
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  // Refs for accumulating transcription
  const userBufferRef = useRef('');
  const agentBufferRef = useRef('');
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatHistory, streamingMessage]);

  // Logging helper
  const addLog = (type: 'user' | 'agent' | 'tool', text?: string, data?: any) => {
    setLogs(prev => [...prev, { id: Date.now().toString(), type, text, data, timestamp: new Date() }].slice(-5)); // Keep last 5
  };

  const handleConnect = async () => {
    if (isConnected) return; // Prevent double connect

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) throw new Error("API Key not found");

      const ai = new GoogleGenAI({ apiKey });
      
      // Reset State
      setChatHistory([]);
      setStreamingMessage(null);
      userBufferRef.current = '';
      agentBufferRef.current = '';
      
      // Audio Setup
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      inputAudioContextRef.current = inputCtx;
      outputAudioContextRef.current = outputCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            console.log("Connection opened");
            setIsConnected(true);
            
            // Setup Input Stream
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            // Handle Transcription
            const { serverContent } = msg;
            if (serverContent) {
              if (serverContent.inputTranscription) {
                userBufferRef.current += serverContent.inputTranscription.text;
                setStreamingMessage({ id: 'temp-user', role: 'user', text: userBufferRef.current });
              }
              
              if (serverContent.outputTranscription) {
                // If user was speaking/typing, flush it
                if (userBufferRef.current) {
                  setChatHistory(prev => [...prev, { id: Date.now() + '-u', role: 'user', text: userBufferRef.current }]);
                  userBufferRef.current = '';
                }
                agentBufferRef.current += serverContent.outputTranscription.text;
                setStreamingMessage({ id: 'temp-agent', role: 'agent', text: agentBufferRef.current });
              }
              
              if (serverContent.turnComplete) {
                // Flush both buffers on turn complete
                if (userBufferRef.current) {
                   setChatHistory(prev => [...prev, { id: Date.now() + '-u', role: 'user', text: userBufferRef.current }]);
                   userBufferRef.current = '';
                }
                if (agentBufferRef.current) {
                   setChatHistory(prev => [...prev, { id: Date.now() + '-a', role: 'agent', text: agentBufferRef.current }]);
                   agentBufferRef.current = '';
                }
                setStreamingMessage(null);
              }

              if (serverContent.interrupted) {
                 if (agentBufferRef.current) {
                   setChatHistory(prev => [...prev, { id: Date.now() + '-a', role: 'agent', text: agentBufferRef.current + '...' }]);
                   agentBufferRef.current = '';
                 }
                 setStreamingMessage(null);
              }
            }

            // Handle Tool Calls
            if (msg.toolCall) {
              addLog('tool', 'Executing Merchant Tools...');
              
              for (const fc of msg.toolCall.functionCalls) {
                let result: any = {};
                
                try {
                  if (fc.name === 'list_products') {
                    const filters = fc.args as any;
                    const items = list_products(filters);
                    setProducts(items); // Update UI
                    setLastOrder(null); // Clear order view
                    result = { products: items };
                    addLog('tool', `Found ${items.length} products`, items);
                  } 
                  else if (fc.name === 'create_order') {
                    const args = fc.args as any;
                    const order = create_order(args.line_items);
                    setLastOrder(order); // Update UI
                    setProducts([]); // Clear product view
                    result = { order_id: order.id, total: order.total, status: 'confirmed' };
                    addLog('tool', `Order ${order.id} Created`, order);
                  }
                  else if (fc.name === 'get_last_order') {
                    const order = get_last_order();
                    if (order) {
                      setLastOrder(order);
                      setProducts([]);
                      result = order;
                      addLog('tool', 'Retrieved last order', order);
                    } else {
                      result = { message: "No previous orders found." };
                    }
                  }
                } catch (err: any) {
                  result = { error: err.message };
                }

                // Send Response back to model
                sessionPromise.then(session => {
                  session.sendToolResponse({
                    functionResponses: {
                      id: fc.id,
                      name: fc.name,
                      response: { result }
                    }
                  });
                });
              }
            }

            // Handle Audio Output
            const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData) {
              setIsSpeaking(true);
              const ctx = outputAudioContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const audioBuffer = await decodeAudioData(
                decode(audioData),
                ctx,
                24000,
                1
              );
              
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsSpeaking(false);
              });

              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }
          },
          onclose: () => {
            console.log("Connection closed");
            setIsConnected(false);
            setIsSpeaking(false);
          },
          onerror: (e) => {
            console.error("Error", e);
            setIsConnected(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: SYSTEM_INSTRUCTION,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
          },
          tools: [
             { functionDeclarations: [listProductsTool, createOrderTool, getLastOrderTool] }
          ]
        }
      });
      
      sessionPromiseRef.current = sessionPromise;

    } catch (err) {
      console.error("Connection failed", err);
      alert("Failed to connect. Check API Key and Permissions.");
    }
  };

  const disconnect = () => {
    // Note: Live API doesn't expose a clean generic 'disconnect' on the promise wrapper easily 
    // without the session object, but purely reloading or stopping audio context works for demo.
    window.location.reload(); 
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center p-4 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-900/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-900/20 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <header className="z-10 w-full max-w-4xl flex justify-between items-center py-6 border-b border-slate-700/50">
        <div className="flex items-center gap-2">
           <div className="w-8 h-8 bg-gradient-to-tr from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center font-bold text-slate-900">C</div>
           <h1 className="text-2xl font-bold tracking-tight">Cortex<span className="text-cyan-400">X</span>Shop</h1>
        </div>
        <div className="text-xs font-mono text-slate-400">
           STATUS: <span className={isConnected ? "text-green-400" : "text-red-400"}>{isConnected ? "ONLINE" : "OFFLINE"}</span>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-4xl z-10 flex flex-col items-center justify-start mt-8 gap-8">
        
        {/* Interaction Center */}
        <div className="w-full flex flex-col items-center gap-6">
          <div className="relative">
             {!isConnected ? (
                <button 
                  onClick={handleConnect}
                  className="px-8 py-4 bg-cyan-600 hover:bg-cyan-500 text-white rounded-full font-semibold text-lg shadow-[0_0_20px_rgba(8,145,178,0.5)] transition-all transform hover:scale-105 active:scale-95"
                >
                  Start Shopping Session
                </button>
             ) : (
                <div className="flex flex-col items-center gap-4">
                  <div className="text-slate-400 text-sm animate-pulse">
                    {isSpeaking ? "Agent Speaking..." : "Listening..."}
                  </div>
                  <Visualizer isActive={isConnected} isSpeaking={isSpeaking} />
                  <button 
                    onClick={disconnect}
                    className="mt-4 text-xs text-red-400 hover:text-red-300 underline"
                  >
                    End Session
                  </button>
                </div>
             )}
          </div>
        </div>

        {/* Conversation Box (Middle Area) */}
        {isConnected && (
          <div className="w-full max-w-2xl bg-slate-800/50 border border-slate-700 rounded-xl p-4 h-64 overflow-y-auto flex flex-col gap-3 backdrop-blur-sm shadow-inner" ref={chatScrollRef}>
             {chatHistory.length === 0 && !streamingMessage && (
               <div className="flex-1 flex items-center justify-center text-slate-500 text-sm italic">
                  Start speaking to browse products...
               </div>
             )}
             {chatHistory.map((msg) => (
               <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                 <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                   msg.role === 'user' 
                     ? 'bg-cyan-600/80 text-white rounded-tr-none' 
                     : 'bg-slate-700/80 text-slate-100 rounded-tl-none'
                 }`}>
                   {msg.text}
                 </div>
               </div>
             ))}
             {streamingMessage && (
               <div className={`flex ${streamingMessage.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                 <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm animate-pulse ${
                   streamingMessage.role === 'user' 
                     ? 'bg-cyan-600/50 text-white rounded-tr-none border border-cyan-500/30' 
                     : 'bg-slate-700/50 text-slate-100 rounded-tl-none border border-slate-600/30'
                 }`}>
                   {streamingMessage.text}
                 </div>
               </div>
             )}
          </div>
        )}

        {/* Dynamic Display Area */}
        <div className="w-full min-h-[300px] bg-slate-800/30 rounded-2xl border border-slate-700 p-6 backdrop-blur-sm">
           
           {/* Default State */}
           {!lastOrder && products.length === 0 && (
             <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-2">
                <svg className="w-12 h-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                <p>Catalog items and orders will appear here.</p>
                {isConnected && <p className="text-sm text-cyan-400/70">"Show me coffee mugs..."</p>}
             </div>
           )}

           {/* Products Grid */}
           <ProductList products={products} />

           {/* Order Receipt */}
           <OrderCard order={lastOrder} />

        </div>

        {/* Activity Log (Mini Debugger for Transparency) */}
        <div className="w-full max-h-32 overflow-hidden border-t border-slate-700 pt-4 opacity-50 hover:opacity-100 transition-opacity">
           <h4 className="text-xs uppercase font-bold text-slate-500 mb-2">System Activity</h4>
           <div className="space-y-1">
             {logs.map((log) => (
               <div key={log.id} className="text-xs font-mono truncate">
                 <span className="text-slate-500">[{log.timestamp.toLocaleTimeString()}]</span>{' '}
                 <span className={`${log.type === 'tool' ? 'text-yellow-500' : 'text-cyan-500'}`}>{log.type.toUpperCase()}</span>:{' '}
                 <span className="text-slate-300">{log.text}</span>
               </div>
             ))}
           </div>
        </div>

      </main>
    </div>
  );
};

export default App;