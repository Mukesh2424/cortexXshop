import { Product, Order, OrderItem } from '../types';

// Mock Catalog
const CATALOG: Product[] = [
  { id: 'p1', name: 'Stoneware Mug', price: 800, category: 'Home', color: 'Blue', image: 'https://picsum.photos/200/200?random=1' },
  { id: 'p2', name: 'Stoneware Mug', price: 800, category: 'Home', color: 'Black', image: 'https://picsum.photos/200/200?random=2' },
  { id: 'p3', name: 'Cyber Hoodie', price: 2500, category: 'Apparel', color: 'Black', size: 'M', image: 'https://picsum.photos/200/200?random=3' },
  { id: 'p4', name: 'Cyber Hoodie', price: 2500, category: 'Apparel', color: 'Black', size: 'L', image: 'https://picsum.photos/200/200?random=4' },
  { id: 'p5', name: 'Classic T-Shirt', price: 600, category: 'Apparel', color: 'White', size: 'L', image: 'https://picsum.photos/200/200?random=5' },
  { id: 'p6', name: 'Spicy Chips', price: 150, category: 'Snacks', image: 'https://picsum.photos/200/200?random=6' },
  { id: 'p7', name: 'Dark Roast Coffee Beans', price: 1200, category: 'Food', image: 'https://picsum.photos/200/200?random=7' },
  { id: 'p8', name: 'Neon Cap', price: 900, category: 'Apparel', color: 'Pink', image: 'https://picsum.photos/200/200?random=8' },
];

let orders: Order[] = [];

// Helper to simulate DB query
export const list_products = (filters: Record<string, any> = {}): Product[] => {
  console.log("Searching catalog with filters:", filters);
  
  return CATALOG.filter(product => {
    let match = true;
    
    // Case-insensitive exact match for category/color/size if provided
    if (filters.category && product.category.toLowerCase() !== filters.category.toLowerCase()) match = false;
    if (filters.color && product.color?.toLowerCase() !== filters.color.toLowerCase()) match = false;
    if (filters.size && product.size?.toLowerCase() !== filters.size.toLowerCase()) match = false;
    
    // Price range logic
    if (filters.max_price && product.price > filters.max_price) match = false;
    if (filters.min_price && product.price < filters.min_price) match = false;

    // Fuzzy name search if needed (simple includes)
    if (filters.search_term && !product.name.toLowerCase().includes(filters.search_term.toLowerCase())) match = false;

    return match;
  });
};

export const create_order = (line_items: OrderItem[]): Order => {
  const items = line_items.map(item => {
    const product = CATALOG.find(p => p.id === item.product_id);
    if (!product) throw new Error(`Product ID ${item.product_id} not found.`);
    return { product, quantity: item.quantity };
  });

  const total = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  const newOrder: Order = {
    id: `ORD-${Math.floor(Math.random() * 10000)}`,
    items,
    total,
    date: new Date().toISOString()
  };

  orders.push(newOrder);
  return newOrder;
};

export const get_last_order = (): Order | null => {
  if (orders.length === 0) return null;
  return orders[orders.length - 1];
};