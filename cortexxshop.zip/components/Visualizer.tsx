import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  isActive: boolean;
  isSpeaking: boolean;
}

export const Visualizer: React.FC<VisualizerProps> = ({ isActive, isSpeaking }) => {
  const barsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    let interval: number;

    if (isActive) {
      interval = window.setInterval(() => {
        barsRef.current.forEach((bar, i) => {
          if (bar) {
            // Random height generation to simulate voice activity
            const baseHeight = isSpeaking ? 30 : 10;
            const variance = isSpeaking ? 50 : 10;
            const height = Math.max(5, Math.random() * variance + baseHeight);
            bar.style.height = `${height}%`;
          }
        });
      }, 100);
    } else {
       // Reset
       barsRef.current.forEach(bar => {
         if (bar) bar.style.height = '10%';
       });
    }

    return () => clearInterval(interval);
  }, [isActive, isSpeaking]);

  return (
    <div className="flex items-center justify-center gap-1 h-32 w-full max-w-xs mx-auto">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          ref={(el) => (barsRef.current[i] = el!) as any}
          className={`w-3 rounded-full transition-all duration-100 ${
             isActive ? (isSpeaking ? 'bg-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.8)]' : 'bg-cyan-700') : 'bg-slate-700'
          }`}
          style={{ height: '10%' }}
        />
      ))}
    </div>
  );
};