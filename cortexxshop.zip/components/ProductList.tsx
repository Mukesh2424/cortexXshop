import React from 'react';
import { Product, Order } from '../types';

interface ProductListProps {
  products: Product[];
}

export const ProductList: React.FC<ProductListProps> = ({ products }) => {
  if (products.length === 0) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4 w-full">
      {products.map((p) => (
        <div key={p.id} className="bg-slate-800 border border-slate-700 rounded-xl p-4 flex flex-col items-center text-center shadow-lg transform transition hover:scale-105">
          <img src={p.image} alt={p.name} className="w-32 h-32 object-cover rounded-lg mb-3 bg-slate-700" />
          <h3 className="text-lg font-semibold text-white">{p.name}</h3>
          <p className="text-slate-400 text-sm mb-1">{p.category} • {p.color} {p.size ? `• ${p.size}` : ''}</p>
          <p className="text-cyan-400 font-bold text-xl">{p.price} INR</p>
          <div className="mt-2 text-xs text-slate-500 font-mono">ID: {p.id}</div>
        </div>
      ))}
    </div>
  );
};

interface OrderCardProps {
  order: Order | null;
}

export const OrderCard: React.FC<OrderCardProps> = ({ order }) => {
  if (!order) return null;

  return (
    <div className="bg-gradient-to-br from-green-900/40 to-slate-900 border border-green-500/50 rounded-xl p-6 w-full max-w-md mx-auto mt-6 shadow-2xl">
      <div className="flex justify-between items-center mb-4 border-b border-green-500/30 pb-2">
        <h2 className="text-xl font-bold text-green-400">Order Confirmed</h2>
        <span className="text-xs font-mono text-green-300">{order.id}</span>
      </div>
      <div className="space-y-2 mb-4">
        {order.items.map((item, idx) => (
          <div key={idx} className="flex justify-between text-sm">
            <span className="text-slate-200">{item.quantity}x {item.product.name} ({item.product.color})</span>
            <span className="text-slate-400">{item.product.price * item.quantity} INR</span>
          </div>
        ))}
      </div>
      <div className="flex justify-between items-center pt-2 border-t border-green-500/30">
        <span className="font-semibold text-slate-300">Total</span>
        <span className="text-2xl font-bold text-white">{order.total} INR</span>
      </div>
    </div>
  );
};